import torch.optim as optim
import random
import numpy as np
import torch.nn as nn
from dg_model import BaseModel
from data_utils import load_case_data, normalize_samples

from torch.optim.lr_scheduler import CosineAnnealingLR
import torch
from torch.utils.data import TensorDataset, DataLoader
import pandas as pd
import os
from sklearn.metrics import f1_score
import argparse

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class Config:
    def __init__(self, dataset_name="pdbu", data_root=None, results_root=None):
        self.dataset_name = dataset_name

        # 定义要使用的损失类型
        # self.distance_metrics = ['wasserstein', 'cosine', 'euclidean', 'spherical', 'hyperbolic']
        self.distance_metrics = ['cosine']

        # 实验配置
        self.experiment = {
            'domains': ['all_data'],  # 域选择
            'base_result_filename': f'ep50_bs100_{dataset_name}_results_9ks_d6_h32_3type040506'
        }

        # 根据数据集名称设置不同的配置
        if dataset_name == "hnust_6204":
            self.working_conditions = ["6204_000w", "6204_200w", "6204_400w"]
            self.base_data_root = r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hnust_6204"
            self.base_results_dir = f"./results_diffusion_hnust"
        elif dataset_name == "hnust_6205":
            self.working_conditions = ["6205_000w", "6205_200w", "6205_400w"]
            self.base_data_root = r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hnust_6205"
            self.base_results_dir = f"./results_diffusion_hnust"
        elif dataset_name == "hnust_6206":
            self.working_conditions = ["6206_000w", "6206_200w", "6206_400w"]
            self.base_data_root = r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hnust_6206"
            self.base_results_dir = f"./results_diffusion_hnust"
        elif dataset_name == "pdbu":
            self.working_conditions = ["real_pitting_L2_1500rpm_07M_04F","real_pitting_L2_1500rpm_01M_10F",
                                       "real_pitting_L2_1500rpm_07M_10F"]
            self.base_data_root = r"E:\Dengzihao\DATASET\Compound_dataset\bearing_pdbu"
            self.base_results_dir = f"./results_diffusion_pdbu"
        elif dataset_name == "hdu":
            self.working_conditions = ["1000rpm_f200", "1000rpm_f400", "1000rpm_f600", "1000rpm_f800"]
            self.base_data_root = r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hdu"
            self.base_results_dir = f"./results_diffusion_hdu"
        elif dataset_name == "hust":
            self.working_conditions = ["Medium_1200rpm", "Medium_1500rpm", "Medium_1800rpm"]
            self.base_data_root = r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hust"
            self.base_results_dir = f"./results_diffusion_hust"
        elif dataset_name == "313lg":
            self.working_conditions = ["900rpm", "1200rpm", "1500rpm", "1800rpm"]
            self.base_data_root = r"E:\Dengzihao\DATASET\Compound_dataset\bearing_313lg"
            self.base_results_dir = f"./results_diffusion_313lg"
        elif dataset_name == "313lb":
            self.working_conditions = [ "950rpm", "1000rpm", "1050rpm", "1100rpm"]
            self.base_data_root = r"E:\Dengzihao\DATASET\Compound_dataset\bearing_313lb"
            self.base_results_dir = f"./results_diffusion_313lb"
        else:
            raise ValueError(f"未知的数据集名称: {dataset_name}")

        if data_root is not None:
            self.base_data_root = data_root
        if results_root is not None:
            self.base_results_dir = results_root

        # 训练参数
        self.training = {
            'epochs': 50,
            'batch_size': 100,
            'run_times': 5,
            'base_seed': 42,  # 初始种子值
            'seed_increment': 1,  # 每次运行的种子增量
        }

        # 优化器参数
        self.optimizer = {
            'type': 'AdamW',
            'lr': 1e-4,
            'weight_decay': 1e-5,
            'betas': (0.9, 0.999)
        }

        # 模型参数
        self.model = {
            'scheduler': 'CosineAnnealingLR',
            'scheduler_params': {
                'T_max': 1000,  # 实际值在代码中动态计算
                'eta_min': 1e-4
            }
        }

    def get_result_filename(self, distance_metric):
        """根据距离度量类型生成结果文件名"""
        return f"{self.experiment['base_result_filename']}_{distance_metric}"

    def get_compound_samples_path(self, condition):
        """根据工况获取复合故障样本路径"""
        return os.path.join(self.base_results_dir, condition, "test_results_500_GW2.0", "compound_samples",
                            "compound_fault_samples.npy")

    def get_single_samples_path(self, condition):
        """根据工况获取单类故障样本路径"""
        return os.path.join(self.base_results_dir, condition, "test_results_500_GW2.0", "single_samples",
                            "all_single_samples.npy")

    def get_single_labels_path(self, condition):
        """根据工况获取单类故障标签路径"""
        return os.path.join(self.base_results_dir, condition, "test_results_500_GW2.0", "single_samples",
                            "all_single_labels.npy")

    def get_train_data_path(self, condition):
        """根据工况获取训练数据路径"""
        return os.path.join(self.base_data_root, condition)


def randomseed(seed):
    """设置所有随机种子"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def extract_case_id(path):
    """智能工况标识提取函数"""
    return os.path.basename(path)


def load_compound_samples(compound_file_path):
    """加载复合故障样本并打上标签3"""
    compound_samples = np.load(compound_file_path)

    if compound_samples.ndim == 3:
        compound_samples = compound_samples.squeeze(axis=1)

    compound_labels = np.full(compound_samples.shape[0], 3, dtype=np.int64)

    print(f"成功加载复合故障样本: {compound_samples.shape}")
    print(f"复合故障标签分布: {np.bincount(compound_labels)}")

    return compound_samples[:, :], compound_labels[:]


def load_single_samples(single_samples_path, single_labels_path):
    """加载单类故障样本（包括健康状态）"""
    single_samples = np.load(single_samples_path)
    single_labels = np.load(single_labels_path)

    if single_samples.ndim == 3:
        single_samples = single_samples.squeeze(axis=1)

    print(f"成功加载单类故障样本: {single_samples.shape}")
    print(f"单类故障标签分布: {np.bincount(single_labels)}")

    return single_samples, single_labels


def train_model(train_data, model_no, current_seed, cfg, train_data_path, distance_metric):
    """训练模型函数"""
    randomseed(current_seed)

    model = BaseModel(distance_metric=distance_metric).to(device)

    train_x, train_y = train_data

    # 将整数标签转换为二元编码
    binary_labels = []
    for label in train_y:
        if label == 0:  # 正常
            binary_labels.append([0, 0])
        elif label == 1:  # 内圈故障
            binary_labels.append([1, 0])
        elif label == 2:  # 外圈故障
            binary_labels.append([0, 1])
        elif label == 3:  # 复合故障
            binary_labels.append([1, 1])
    train_y_binary = np.array(binary_labels, dtype=np.float32)

    train_x = normalize_samples(train_x)

    x_tensor = torch.from_numpy(train_x).float()
    y_tensor = torch.from_numpy(train_y_binary).float()
    label_tensor = torch.from_numpy(train_y).long()  # 添加原始标签tensor

    dataset = TensorDataset(x_tensor.to(device), y_tensor.to(device), label_tensor.to(device))
    train_loader = DataLoader(
        dataset,
        batch_size=cfg.training['batch_size'],
        shuffle=True,
    )

    optimizer_main = getattr(optim, cfg.optimizer['type'])(
        model.parameters(),
        lr=cfg.optimizer['lr'],
        weight_decay=cfg.optimizer['weight_decay'],
        betas=cfg.optimizer['betas']
    )

    model.train()
    total_steps = cfg.training['epochs'] * len(train_loader)
    scheduler_main = CosineAnnealingLR(optimizer_main, T_max=total_steps, eta_min=1e-6)

    criterion = nn.BCELoss()

    for epoch in range(cfg.training['epochs']):
        model.train()
        total_loss = 0.0
        total_cls_loss = 0.0
        total_align_loss = 0.0
        total_samples = 0

        for batch_idx, (batch_x, batch_y, batch_labels) in enumerate(train_loader):
            # 前向传播获取分类输出
            preds = model(batch_x)  # 只返回分类输出
            cls_loss = criterion(preds, batch_y)

            align_loss = torch.tensor(0.0, device=device)

            align_loss = model.compute_loss(
                batch_x,
                batch_labels  # 传入原始标签
            )

            total_batch_loss = cls_loss + align_loss

            optimizer_main.zero_grad()
            total_batch_loss.backward()
            optimizer_main.step()
            scheduler_main.step()

            total_loss += total_batch_loss.item() * batch_x.size(0)
            total_cls_loss += cls_loss.item() * batch_x.size(0)
            total_align_loss += align_loss.item() * batch_x.size(0)
            total_samples += batch_x.size(0)

        avg_loss = total_loss / total_samples
        avg_cls_loss = total_cls_loss / total_samples
        avg_align_loss = total_align_loss / total_samples

        if (epoch + 1) % 10 == 0 or epoch == 0:
            print(f"Epoch {epoch + 1}/{cfg.training['epochs']}, "
                  f"Total Loss: {avg_loss:.4f}, "
                  f"Cls Loss: {avg_cls_loss:.4f}, "
                  f"Align Loss: {avg_align_loss:.4f}")

    torch.save(model.state_dict(), f"model_{model_no}_{distance_metric}.pth")
    return model


def eval_model(test_x, test_y, model_no, cfg, case_id, train_data_path, distance_metric):
    """测试模型函数 - 返回准确率和宏F1"""
    model_test = BaseModel(distance_metric=distance_metric).to(device)
    model_test.load_state_dict(torch.load(f"model_{model_no}_{distance_metric}.pth", weights_only=True))
    model_test.eval()

    binary_labels = []
    for label in test_y:
        if label == 0:  # 正常
            binary_labels.append([0, 0])
        elif label == 1:  # 内圈故障
            binary_labels.append([1, 0])
        elif label == 2:  # 外圈故障
            binary_labels.append([0, 1])
        elif label == 3:  # 复合故障
            binary_labels.append([1, 1])
    test_y_binary = np.array(binary_labels, dtype=np.float32)

    test_x = normalize_samples(test_x)

    test_x_tensor = torch.tensor(test_x, dtype=torch.float32).to(device)
    test_y_tensor = torch.tensor(test_y_binary, dtype=torch.float32).to(device)

    with torch.no_grad():
        # 修改这里：直接获取预测结果，不再解包
        preds = model_test(test_x_tensor)

    binary_preds = (preds >= 0.5).int()
    correct = (binary_preds == test_y_tensor).all(dim=1).float()
    accuracy = correct.mean()

    # 计算F1分数 - 只保留宏F1
    int_preds = []
    for pred in binary_preds.cpu().numpy():
        if np.array_equal(pred, [0, 0]):
            int_preds.append(0)
        elif np.array_equal(pred, [1, 0]):
            int_preds.append(1)
        elif np.array_equal(pred, [0, 1]):
            int_preds.append(2)
        elif np.array_equal(pred, [1, 1]):
            int_preds.append(3)
    int_preds = np.array(int_preds)

    int_true = []
    for true in test_y_tensor.cpu().numpy():
        if np.array_equal(true, [0, 0]):
            int_true.append(0)
        elif np.array_equal(true, [1, 0]):
            int_true.append(1)
        elif np.array_equal(true, [0, 1]):
            int_true.append(2)
        elif np.array_equal(true, [1, 1]):
            int_true.append(3)
    int_true = np.array(int_true)

    # 只计算宏平均F1
    macro_f1 = f1_score(int_true, int_preds, average='macro')

    print(f"Model {model_no} ({distance_metric}) Test Accuracy: {accuracy.item():.2%}")
    print(f"Macro F1: {macro_f1:.4f}")

    return accuracy.item(), int_preds, int_true, macro_f1


def load_all_eval_cases():
    """加载所有测试工况数据"""
    test_case_data = {}

    for condition in cfg.working_conditions:
        test_path = cfg.get_train_data_path(condition)
        case_id = extract_case_id(test_path)
        print(f"Loading test case: {case_id}")

        train_x, train_y, test_x, test_y = load_case_data(test_path)

        test_case_data[case_id] = (test_x, test_y)

    return test_case_data


def main():
    parser = argparse.ArgumentParser(description="Train and evaluate the DSC diagnosis model.")
    parser.add_argument("--dataset", default="313lb", choices=[
        "hnust_6204", "hnust_6205", "hnust_6206", "pdbu", "hdu", "hust", "313lg", "313lb"
    ])
    parser.add_argument("--data-root", default=None,
                        help="Dataset root containing one subdirectory per working condition.")
    parser.add_argument("--results-root", default=None,
                        help="Root directory containing diffusion outputs for each condition.")
    parser.add_argument("--distance-metric", default=None,
                        choices=["cosine", "euclidean", "wasserstein", "spherical", "hyperbolic"])
    parser.add_argument("--runs", type=int, default=None,
                        help="Number of repeated diagnostic runs.")
    args = parser.parse_args()

    # 定义要处理的所有数据集
    all_datasets = [args.dataset]

    # 存储所有数据集的结果
    all_datasets_results = []

    for dataset_name in all_datasets:
        print(f"\n{'=' * 80}")
        print(f"开始处理数据集: {dataset_name}")
        print(f"{'=' * 80}")

        # 为当前数据集创建配置
        global cfg
        cfg = Config(dataset_name, data_root=args.data_root, results_root=args.results_root)
        if args.distance_metric is not None:
            cfg.distance_metrics = [args.distance_metric]
        if args.runs is not None:
            cfg.training['run_times'] = args.runs

        # 循环处理每种距离度量
        for distance_metric in cfg.distance_metrics:
            print(f"\n{'=' * 80}")
            print(f"开始使用距离度量: {distance_metric}")
            print(f"{'=' * 80}")

            # 为当前距离度量创建结果目录
            metric_results_dir = f"results_{dataset_name}_{distance_metric}"
            os.makedirs(metric_results_dir, exist_ok=True)

            # 存储当前距离度量所有工况的结果
            all_results = []

            # 循环处理当前数据集的每个工况
            for condition in cfg.working_conditions:
                print(f"\n{'=' * 60}")
                print(f"开始处理工况: {condition} (距离度量: {distance_metric})")
                print(f"{'=' * 60}")

                # 设置当前工况的路径
                train_data_path = cfg.get_train_data_path(condition)
                compound_samples_path = cfg.get_compound_samples_path(condition)
                single_samples_path = cfg.get_single_samples_path(condition)
                single_labels_path = cfg.get_single_labels_path(condition)

                print(f"训练数据路径: {train_data_path}")
                print(f"复合故障样本路径: {compound_samples_path}")
                print(f"单类故障样本路径: {single_samples_path}")
                print(f"单类故障标签路径: {single_labels_path}")

                # 检查所有样本文件是否存在
                if not os.path.exists(compound_samples_path):
                    print(f"警告: 复合故障样本路径不存在: {compound_samples_path}")
                    print(f"跳过工况: {condition}")
                    continue

                if not os.path.exists(single_samples_path) or not os.path.exists(single_labels_path):
                    print(f"警告: 单类故障样本路径不存在: {single_samples_path} 或 {single_labels_path}")
                    print(f"跳过工况: {condition}")
                    continue

                randomseed(cfg.training['base_seed'])

                # 1. 加载原始训练数据
                print(f"Loading original training data from: {train_data_path}")
                train_x, train_y, test_x, test_y = load_case_data(train_data_path)

                # 只保留标签0-2的单类故障样本
                single_fault_mask = train_y < 3
                train_x_single = train_x[single_fault_mask]
                train_y_single = train_y[single_fault_mask]

                print("\n=== 单类故障训练数据标签分布 ===")
                print(f"单类故障训练数据 train_y 的标签分布: {np.bincount(train_y_single)}")
                print(f"单类故障训练数据 train_y 的唯一值: {np.unique(train_y_single)}")

                # 2. 加载生成的单类故障样本（包括健康状态）
                print(f"Loading generated single fault samples from: {single_samples_path}")
                generated_single_samples, generated_single_labels = load_single_samples(single_samples_path,
                                                                                        single_labels_path)

                # 3. 加载生成的复合故障样本
                print(f"Loading generated compound fault samples from: {compound_samples_path}")
                compound_samples, compound_labels = load_compound_samples(compound_samples_path)

                # 4. 合并所有样本：原始单类样本 + 生成单类样本 + 生成复合样本（取消数量限制）
                print("\n=== 合并所有训练样本（取消数量限制） ===")

                # 直接使用所有原始单类样本（取消数量限制）
                original_x = train_x_single
                original_y = train_y_single

                # 直接使用所有生成单类样本（取消数量限制）
                generated_single_x = generated_single_samples
                generated_single_y = generated_single_labels

                # 直接使用所有复合故障样本（取消数量限制）
                compound_x = compound_samples
                compound_y = compound_labels

                # 合并所有样本（不使用任何数量限制）
                all_samples_list = [original_x, generated_single_x, compound_x]
                all_labels_list = [original_y, generated_single_y, compound_y]

                all_train_samples = np.vstack(all_samples_list)
                all_train_labels = np.concatenate(all_labels_list)

                print(f"合并后的训练样本形状: {all_train_samples.shape}")
                print(f"合并后的训练标签形状: {all_train_labels.shape}")
                print(f"合并后的标签分布: {np.bincount(all_train_labels)}")
                print(f"各类别样本数:")
                class_names = ['Normal', 'BPFI', 'BPFO', 'Compound']
                for i, count in enumerate(np.bincount(all_train_labels)):
                    if count > 0:
                        print(f"  类别 {i} ({class_names[i]}): {count} 样本")
                        if i < 3:
                            original_count = np.sum(original_y == i)
                            generated_count = np.sum(generated_single_y == i)
                            print(f"    - 原始样本: {original_count}, 生成样本: {generated_count}")

                # 5. 加载所有测试数据
                print("Loading all test cases...")
                test_case_data = load_all_eval_cases()

                print("\n=== 测试集标签和样本分布 ===")
                for case_id, (test_x, test_y) in test_case_data.items():
                    print(f"\n测试案例: {case_id}")
                    print(f"总样本数: {len(test_y)}")
                    print(f"标签分布: {np.bincount(test_y)}")
                    print(f"各类别样本数:")
                    for i, count in enumerate(np.bincount(test_y)):
                        if count > 0:
                            print(f"  类别 {i} ({class_names[i]}): {count} 样本")

                # 6. 运行多次实验
                results = []
                run_accuracies = {}
                run_f1_scores = {}

                for run in range(cfg.training['run_times']):
                    current_seed = cfg.training['base_seed'] + run * cfg.training['seed_increment']
                    print(
                        f"\n=== 开始运行 {run + 1}/{cfg.training['run_times']}, 使用种子: {current_seed}, 距离度量: {distance_metric} ===")

                    # 训练模型（传递距离度量类型）
                    print(f"开始训练模型 {run + 1}/{cfg.training['run_times']}")
                    train_model((all_train_samples, all_train_labels), run, current_seed, cfg, train_data_path, distance_metric)

                    # 测试所有目标工况
                    run_accuracies[run] = {}
                    run_f1_scores[run] = {}
                    print(f"\n=== 测试模型 {run + 1}/{cfg.training['run_times']} ===")

                    for case_id, (test_x, test_y) in test_case_data.items():
                        acc, preds, true_labels, macro_f1 = eval_model(
                            test_x, test_y, run, cfg, case_id, train_data_path, distance_metric
                        )
                        run_accuracies[run][case_id] = acc
                        run_f1_scores[run][case_id] = macro_f1

                        result_row = {
                            'Dataset': dataset_name,
                            'Distance Metric': distance_metric,
                            'Working Condition': condition,
                            'Run': run + 1,
                            'Test Case': case_id,
                            'Accuracy': acc,
                            'Macro_F1': macro_f1
                        }
                        results.append(result_row)
                        all_results.append(result_row)
                        all_datasets_results.append(result_row)

                        print(f"Run {run + 1}, Test Case {case_id}: 准确率={acc:.2%}, 宏F1={macro_f1:.4f}")

                # 7. 创建结果表格（当前工况）
                results_df = pd.DataFrame(results)

                # 计算统计信息 - 只保留准确率和宏F1
                avg_acc = results_df.groupby('Test Case')['Accuracy'].mean().reset_index()
                std_acc = results_df.groupby('Test Case')['Accuracy'].std().reset_index()

                avg_acc.columns = ['Test Case', 'Average Accuracy']
                std_acc.columns = ['Test Case', 'Std Accuracy']

                stats_df = pd.merge(avg_acc, std_acc, on='Test Case')

                # 计算宏F1统计信息
                avg_macro_f1 = results_df.groupby('Test Case')['Macro_F1'].mean().reset_index()
                std_macro_f1 = results_df.groupby('Test Case')['Macro_F1'].std().reset_index()

                avg_macro_f1.columns = ['Test Case', 'Avg_Macro_F1']
                std_macro_f1.columns = ['Test Case', 'Std_Macro_F1']

                stats_df = pd.merge(stats_df, avg_macro_f1, on='Test Case')
                stats_df = pd.merge(stats_df, std_macro_f1, on='Test Case')

                overall_avg = results_df['Accuracy'].mean()
                overall_std = results_df['Accuracy'].std()
                overall_avg_f1 = results_df['Macro_F1'].mean()
                overall_std_f1 = results_df['Macro_F1'].std()

                print(f"\n=== {condition} ({distance_metric}) 最终统计结果 ===")
                print(f"总体平均准确率: {overall_avg:.2%} ± {overall_std:.2%}")
                print(f"总体平均宏F1: {overall_avg_f1:.4f} ± {overall_std_f1:.4f}")
                print(f"距离度量: {distance_metric}")
                print("\n各测试案例详细统计:")
                for _, row in stats_df.iterrows():
                    print(f"{row['Test Case']}: 准确率={row['Average Accuracy']:.2%} ± {row['Std Accuracy']:.2%}, "
                          f"宏F1={row['Avg_Macro_F1']:.4f} ± {row['Std_Macro_F1']:.4f}")

                # 保存当前工况结果到距离度量目录
                result_filename = cfg.get_result_filename(distance_metric)
                output_path = f"{metric_results_dir}/{result_filename}_{condition}_results.xlsx"
                with pd.ExcelWriter(output_path) as writer:
                    results_df.to_excel(writer, sheet_name='Detailed Results', index=False)
                    stats_df.to_excel(writer, sheet_name='Statistics', index=False)

                    overall_stats = pd.DataFrame({
                        'Metric': ['Overall Average Accuracy', 'Accuracy Std',
                                   'Overall Average Macro F1', 'Macro F1 Std',
                                   'Distance Metric'],
                        'Value': [f"{overall_avg:.2%}", f"{overall_std:.2%}",
                                  f"{overall_avg_f1:.4f}", f"{overall_std_f1:.4f}",
                                  distance_metric]
                    })
                    overall_stats.to_excel(writer, sheet_name='Overall Statistics', index=False)

                    for case_id in results_df['Test Case'].unique():
                        case_data = results_df[results_df['Test Case'] == case_id]
                        case_stats = stats_df[stats_df['Test Case'] == case_id]

                        case_summary = pd.DataFrame({
                            'Run': case_data['Run'],
                            'Accuracy': case_data['Accuracy'],
                            'Macro_F1': case_data['Macro_F1']
                        })

                        stats_row = pd.DataFrame({
                            'Run': ['Average', 'Std'],
                            'Accuracy': [
                                case_stats['Average Accuracy'].values[0],
                                case_stats['Std Accuracy'].values[0]
                            ],
                            'Macro_F1': [
                                case_stats['Avg_Macro_F1'].values[0],
                                case_stats['Std_Macro_F1'].values[0]
                            ]
                        })

                        case_summary = pd.concat([case_summary, stats_row], ignore_index=True)
                        case_summary.to_excel(writer, sheet_name=f"{case_id[:25]}", index=False)

                print(f"\n{condition} ({distance_metric}) 结果已保存至: {output_path}")
                print(f"{condition} ({distance_metric}) 诊断完成！\n")

            # 保存当前距离度量的所有工况汇总结果
            if all_results:
                all_results_df = pd.DataFrame(all_results)
                summary_output_path = f"{metric_results_dir}/{result_filename}_all_conditions_summary.xlsx"

                with pd.ExcelWriter(summary_output_path) as writer:
                    all_results_df.to_excel(writer, sheet_name='All Results', index=False)

                    # 按工况和测试案例分组统计 - 只保留准确率和宏F1
                    summary_stats = all_results_df.groupby(['Working Condition', 'Test Case']).agg({
                        'Accuracy': ['mean', 'std'],
                        'Macro_F1': ['mean', 'std']
                    }).round(4)

                    summary_stats.to_excel(writer, sheet_name='Summary Statistics')

                print(f"{dataset_name} ({distance_metric}) 数据集汇总结果已保存至: {summary_output_path}")

            print(f"{dataset_name} ({distance_metric}) 数据集处理完成！")

        print(f"{dataset_name} 数据集所有距离度量处理完成！")

    # 保存所有数据集和所有距离度量的汇总结果
    if all_datasets_results:
        all_datasets_df = pd.DataFrame(all_datasets_results)
        final_summary_path = "results_all_datasets_all_metrics_summary.xlsx"

        with pd.ExcelWriter(final_summary_path) as writer:
            all_datasets_df.to_excel(writer, sheet_name='All Datasets Results', index=False)

            # 按数据集、距离度量、工况和测试案例分组统计 - 只保留准确率和宏F1
            final_summary = all_datasets_df.groupby(
                ['Dataset', 'Distance Metric', 'Working Condition', 'Test Case']).agg({
                'Accuracy': ['mean', 'std'],
                'Macro_F1': ['mean', 'std']
            }).round(4)

            final_summary.to_excel(writer, sheet_name='Final Summary')

            # 添加距离度量比较表 - 只保留准确率和宏F1
            metric_comparison = all_datasets_df.groupby(['Dataset', 'Distance Metric']).agg({
                'Accuracy': 'mean',
                'Macro_F1': 'mean'
            }).round(4)

            metric_comparison.to_excel(writer, sheet_name='Metric Comparison')

        print(f"所有数据集和所有距离度量汇总结果已保存至: {final_summary_path}")

    print("所有数据集和所有距离度量处理完成！")


if __name__ == "__main__":
    main()
