
import torch
import torch.nn as nn

DATA_LENGTH = 2048
NUM_FEATURES = 192
NUM_CLASSES = 3

# ==================== 模型定义 ====================
# 一维残差卷积块（保持原有结构不变）
class ResidualConvBlock1D(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, is_res: bool = False):
        super().__init__()
        self.same_channels = in_channels == out_channels
        self.is_res = is_res

        self.conv1 = nn.Sequential(
            nn.Conv1d(in_channels, out_channels, 3, 1, 1),
            nn.BatchNorm1d(out_channels),
            nn.GELU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv1d(out_channels, out_channels, 3, 1, 1),
            nn.BatchNorm1d(out_channels),
            nn.GELU(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.is_res:
            x1 = self.conv1(x)
            x2 = self.conv2(x1)
            if self.same_channels:
                out = x + x2
            else:
                out = x1 + x2
            return out / 1.414
        else:
            x1 = self.conv1(x)
            x2 = self.conv2(x1)
            return x2


# 一维下采样模块（增加第三层）
class UnetDown1D(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(UnetDown1D, self).__init__()
        layers = [ResidualConvBlock1D(in_channels, out_channels), nn.MaxPool1d(2)]
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


# 一维上采样模块（增加第三层）
class UnetUp1D(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(UnetUp1D, self).__init__()
        layers = [
            nn.ConvTranspose1d(in_channels, out_channels, 2, 2),
            ResidualConvBlock1D(out_channels, out_channels),
            ResidualConvBlock1D(out_channels, out_channels),
        ]
        self.model = nn.Sequential(*layers)

    def forward(self, x, skip):
        x = torch.cat((x, skip), 1)
        x = self.model(x)
        return x


# 一维嵌入层（保持不变）
class EmbedFC1D(nn.Module):
    def __init__(self, input_dim, emb_dim):
        super(EmbedFC1D, self).__init__()
        self.input_dim = input_dim
        layers = [
            nn.Linear(input_dim, emb_dim),
            nn.GELU(),
            nn.Linear(emb_dim, emb_dim),
        ]
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        x = x.view(-1, self.input_dim)
        return self.model(x)


# 一维条件UNet（修改为3层编码、3层解码）
class ContextUnet1D(nn.Module):
    def __init__(self, in_channels, n_feat=NUM_FEATURES, n_classes=NUM_CLASSES):
        super(ContextUnet1D, self).__init__()

        self.in_channels = in_channels
        self.n_feat = n_feat
        self.n_classes = n_classes

        self.init_conv = nn.Sequential(
            nn.Conv1d(in_channels, n_feat, 3, 1, 1),  # 输入通道数保持不变
            nn.GroupNorm(8, n_feat),
            nn.GELU(),
            nn.Conv1d(n_feat, n_feat, 3, 1, 1),
        )

        # 3层下采样编码器
        self.down1 = UnetDown1D(n_feat, n_feat)
        self.down2 = UnetDown1D(n_feat, 2 * n_feat)
        self.down3 = UnetDown1D(2 * n_feat, 4 * n_feat)  # 新增第三层

        # 根据信号长度调整池化大小（现在需要除以8，因为经过3次下采样）
        signal_length = DATA_LENGTH
        pool_size = signal_length // 8  # 修改为除以8
        self.to_vec = nn.Sequential(nn.AvgPool1d(pool_size), nn.GELU())

        # 增加第三层的嵌入
        self.timeembed1 = EmbedFC1D(1, 4 * n_feat)  # 修改为4*n_feat
        self.timeembed2 = EmbedFC1D(1, 2 * n_feat)
        self.timeembed3 = EmbedFC1D(1, 1 * n_feat)  # 新增第三层时间嵌入
        self.contextembed1 = EmbedFC1D(n_classes, 4 * n_feat)  # 修改为4*n_feat
        self.contextembed2 = EmbedFC1D(n_classes, 2 * n_feat)
        self.contextembed3 = EmbedFC1D(n_classes, 1 * n_feat)  # 新增第三层上下文嵌入

        # 上采样路径（增加第三层）
        self.up0 = nn.Sequential(
            nn.ConvTranspose1d(4 * n_feat, 4 * n_feat, pool_size, pool_size),  # 修改为4*n_feat
            nn.GroupNorm(8, 4 * n_feat),
            nn.GELU(),
        )

        self.up1 = UnetUp1D(8 * n_feat, 2 * n_feat)  # 修改输入通道数为8*n_feat
        self.up2 = UnetUp1D(4 * n_feat, n_feat)  # 修改输入通道数为4*n_feat
        self.up3 = UnetUp1D(2 * n_feat, n_feat)  # 新增第三层上采样

        self.out = nn.Sequential(
            nn.Conv1d(2 * n_feat, n_feat, 3, 1, 1),  # 输入通道数保持不变
            nn.GroupNorm(8, n_feat),
            nn.GELU(),
            nn.Conv1d(n_feat, self.in_channels, 3, 1, 1),
        )

    def forward(self, x, c, t, context_mask):
        # 检查c的维度，如果是一维，则假设是类别索引，转换为one-hot
        if c.dim() == 1:
            c = nn.functional.one_hot(c, num_classes=self.n_classes).type(torch.float)

        # 处理上下文掩码
        context_mask = context_mask[:, None]
        context_mask = context_mask.repeat(1, self.n_classes)
        context_mask = (-1 * (1 - context_mask))
        c = c * context_mask

        # 嵌入式上下文和时间步（增加第三层）
        cemb1 = self.contextembed1(c).view(-1, self.n_feat * 4, 1)  # 修改为4*n_feat
        temb1 = self.timeembed1(t).view(-1, self.n_feat * 4, 1)  # 修改为4*n_feat
        cemb2 = self.contextembed2(c).view(-1, self.n_feat * 2, 1)
        temb2 = self.timeembed2(t).view(-1, self.n_feat * 2, 1)
        cemb3 = self.contextembed3(c).view(-1, self.n_feat, 1)  # 新增第三层
        temb3 = self.timeembed3(t).view(-1, self.n_feat, 1)  # 新增第三层

        # 下采样路径（3层）
        x = self.init_conv(x)
        down1 = self.down1(x)  # 第一层下采样
        down2 = self.down2(down1)  # 第二层下采样
        down3 = self.down3(down2)  # 新增第三层下采样
        hiddenvec = self.to_vec(down3)  # 修改为对down3进行池化

        # 上采样路径（3层）
        up1 = self.up0(hiddenvec)
        up2 = self.up1(cemb1 * up1 + temb1, down3)  # 与第三层下采样结果连接
        up3 = self.up2(cemb2 * up2 + temb2, down2)  # 与第二层下采样结果连接
        up4 = self.up3(cemb3 * up3 + temb3, down1)  # 新增：与第一层下采样结果连接
        out = self.out(torch.cat((up4, x), 1))  # 修改为与up4连接
        return out
