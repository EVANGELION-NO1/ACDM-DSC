import torch.nn as nn
import math
import torch.nn.functional as F
import torch
import numpy as np
from einops import rearrange

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.):
        super().__init__()

        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)


class Attention(nn.Module):
    def __init__(self, dim, heads=8, dim_head=64, dropout=0.):
        super().__init__()
        inner_dim = dim_head * heads
        project_out = not (heads == 1 and dim_head == dim)

        # 保留核心注意力结构
        self.heads = heads
        self.scale = dim_head ** -0.5
        self.norm = nn.LayerNorm(dim)
        self.attend = nn.Softmax(dim=-1)
        self.dropout = nn.Dropout(dropout)
        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False)
        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x):
        x = self.norm(x)
        qkv = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h=self.heads), qkv)
        # print(q.shape, k.shape)
        dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale
        attn = self.attend(dots)
        attn = self.dropout(attn)
        out = torch.matmul(attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)


class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, dim_head, mlp_dim, dropout=0.):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Attention(dim, heads=heads, dim_head=dim_head, dropout=dropout),
                FeedForward(dim, mlp_dim, dropout=dropout)
            ]))

    def forward(self, x):
        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x
        return x


class DistanceMetrics:
    """距离度量工具类"""

    @staticmethod
    def cosine_distance(x1, x2, dim=-1, eps=1e-8):
        """计算余弦距离 (1 - 余弦相似度)"""
        cosine_sim = F.cosine_similarity(x1, x2, dim=dim, eps=eps)
        return 1.0 - cosine_sim

    @staticmethod
    def euclidean_distance(x1, x2, dim=-1):
        """计算欧氏距离"""
        return torch.norm(x1 - x2, p=2, dim=dim)

    @staticmethod
    def wasserstein_distance(x1, x2, method='exact'):
        """
        计算瓦瑟斯坦距离（推土距离）

        Args:
            x1, x2: 特征张量，形状为 [batch_size, feature_dim]
            method: 计算方法，'approximate'为近似计算，'exact'为精确计算（较慢）
        """
        if method == 'approximate':
            # 近似计算：使用均值差异作为简化版本
            mean1, mean2 = x1.mean(dim=0), x2.mean(dim=0)
            cov1 = torch.cov(x1.T) if x1.shape[0] > 1 else torch.eye(x1.shape[1], device=x1.device)
            cov2 = torch.cov(x2.T) if x2.shape[0] > 1 else torch.eye(x2.shape[1], device=x2.device)

            # 使用2-Wasserstein距离的闭式解（高斯分布假设）
            mean_diff = torch.norm(mean1 - mean2, p=2)
            cov_term = torch.trace(cov1 + cov2 - 2 * torch.sqrt(torch.sqrt(cov1) @ cov2 @ torch.sqrt(cov1)))
            return torch.sqrt(mean_diff ** 2 + cov_term)
        else:
            # 精确计算（计算量较大）
            # 这里使用简化的成对距离计算
            n1, n2 = x1.shape[0], x2.shape[0]
            if n1 == 0 or n2 == 0:
                return torch.tensor(0.0, device=x1.device)

            # 计算所有成对距离
            dist_matrix = torch.cdist(x1.unsqueeze(0), x2.unsqueeze(0)).squeeze(0)
            return dist_matrix.mean()

    @staticmethod
    def spherical_distance(x1, x2, dim=-1, eps=1e-8):
        """计算超球面距离（大圆距离）"""
        # 先将向量归一化到单位球面
        x1_norm = F.normalize(x1, p=2, dim=dim)
        x2_norm = F.normalize(x2, p=2, dim=dim)

        # 计算余弦相似度
        cosine_sim = torch.sum(x1_norm * x2_norm, dim=dim)

        # 防止数值误差
        cosine_sim = torch.clamp(cosine_sim, -1 + eps, 1 - eps)

        # 计算角度距离（弧度）
        angular_distance = torch.acos(cosine_sim)

        return angular_distance

    @staticmethod
    def hyperbolic_distance(x1, x2, c=1.0, dim=-1, eps=1e-8):
        """
        基于庞加莱圆盘模型的双曲距离计算

        Args:
            x1, x2: 输入向量，假设已经在双曲空间中（模长 < 1）
            c: 曲率参数
            dim: 计算维度
        """
        # 确保输入在单位圆盘内
        x1_norm = torch.clamp(torch.norm(x1, p=2, dim=dim, keepdim=True), 0, 1 - eps)
        x2_norm = torch.clamp(torch.norm(x2, p=2, dim=dim, keepdim=True), 0, 1 - eps)

        # 庞加莱距离公式
        diff_norm = torch.norm(x1 - x2, p=2, dim=dim, keepdim=True)
        denominator = (1 - x1_norm ** 2) * (1 - x2_norm ** 2)

        # 双曲距离
        hyperbolic_dist = torch.acosh(1 + 2 * diff_norm ** 2 / denominator.clamp(min=eps))

        return hyperbolic_dist.squeeze(dim) / math.sqrt(c)


class FeatureExtractor(nn.Module):
    def __init__(self, dim=512):
        super().__init__()

        self.Econv0 = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=64, kernel_size=9, stride=4, padding=4),
            nn.InstanceNorm1d(64),
            nn.GELU(),
        )

        self.transformer = Transformer(
            dim=dim,
            depth=6,
            heads=32,
            dim_head=256,
            mlp_dim=512,
        )

        # 保持原始的分类器
        self.mlp_head = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, 256),
            nn.GELU(),
            nn.Linear(256, 64),
            nn.GELU(),
            nn.Linear(64, 2),
            nn.Sigmoid()
        )

        self.pool = nn.AdaptiveAvgPool1d(1)

    def forward(self, x, return_features=False):
        x = torch.unsqueeze(x, dim=1)
        x = self.Econv0(x)
        features = self.transformer(x)
        # 使用pool后的transformer层输出的特征作为原始特征
        pooled_features = self.pool(features.transpose(1, 2)).squeeze(-1)

        # 分类
        cls = self.mlp_head(pooled_features)

        if return_features:
            # 返回pool后的transformer特征和分类结果
            return pooled_features, cls
        else:
            return cls


class BaseModel(nn.Module):
    def __init__(self, distance_metric='cosine'):
        """
        Args:
            distance_metric: 距离度量方式，可选 'cosine', 'euclidean', 'wasserstein',
                            'spherical', 'hyperbolic'
        """
        super().__init__()
        self.feature_extractor = FeatureExtractor()

        # 设置距离度量方式
        self.distance_metric = distance_metric
        self.distance_calculator = DistanceMetrics()

        print(f"使用距离度量方式: {distance_metric}")

    def forward(self, x, return_features=False):
        """修改forward方法，支持返回特征"""
        return self.feature_extractor(x, return_features=return_features)

    def compute_loss(self, x, labels):
        """计算损失函数 - 与文档2中的调用匹配"""
        return self.compute_distance_loss(x, labels)

    def compute_distance_loss(self, x, labels):
        batch_size = x.shape[0]

        # 计算原始特征
        original_features, _ = self.forward(x, return_features=True)

        # 使用选择的距离度量方式计算损失
        inter_class_loss = self._compute_enhanced_distance_loss(original_features, labels)

        total_loss = inter_class_loss

        return total_loss

    def _compute_distance(self, x1, x2, reduction='mean'):
        """根据选择的度量方式计算距离"""
        if self.distance_metric == 'cosine':
            distance = self.distance_calculator.cosine_distance(x1, x2)
        elif self.distance_metric == 'euclidean':
            distance = self.distance_calculator.euclidean_distance(x1, x2)
        elif self.distance_metric == 'wasserstein':
            distance = self.distance_calculator.wasserstein_distance(x1, x2)
        elif self.distance_metric == 'spherical':
            distance = self.distance_calculator.spherical_distance(x1, x2)
        elif self.distance_metric == 'hyperbolic':
            distance = self.distance_calculator.hyperbolic_distance(x1, x2)
        else:
            raise ValueError(f"不支持的度量方式: {self.distance_metric}")

        if reduction == 'mean':
            return distance.mean()
        elif reduction == 'sum':
            return distance.sum()
        else:
            return distance

    def _compute_enhanced_distance_loss(self, features, labels):
        """
        增强版的距离损失，使用选择的距离度量方式
        """
        # 只处理故障样本（标签1,2,3）
        fault_indices = (labels > 0) & (labels < 4)  # 标签1,2,3
        if not torch.any(fault_indices):
            return torch.tensor(0.0, device=features.device)

        fault_features = features[fault_indices]
        fault_labels = labels[fault_indices]

        # 获取各类别的特征
        class_features = {}
        for class_id in [1, 2, 3]:  # 内圈、外圈、复合
            class_mask = (fault_labels == class_id)
            if torch.any(class_mask):
                class_features[class_id] = fault_features[class_mask]

        # 如果不足2个类别，无法计算距离损失
        if len(class_features) < 2:
            return torch.tensor(0.0, device=features.device)

        # 计算类内紧凑性（类内样本与类中心的平均距离）
        intra_class_compactness = 0.0
        intra_count = 0

        for class_id, features_in_class in class_features.items():
            if len(features_in_class) > 1:
                class_center = features_in_class.mean(dim=0, keepdim=True)
                # 计算类内样本与类中心的距离
                distances = self._compute_distance(features_in_class,
                                                   class_center.expand_as(features_in_class))
                intra_class_compactness += distances
                intra_count += 1

        if intra_count > 0:
            intra_class_compactness /= intra_count

        # 计算类间分离性（类中心之间的距离）
        inter_class_separation = 0.0
        inter_count = 0

        class_ids = list(class_features.keys())
        for i in range(len(class_ids)):
            for j in range(i + 1, len(class_ids)):
                class_i = class_ids[i]
                class_j = class_ids[j]

                center_i = class_features[class_i].mean(dim=0, keepdim=True)
                center_j = class_features[class_j].mean(dim=0, keepdim=True)

                distance = self._compute_distance(center_i, center_j)
                inter_class_separation += distance
                inter_count += 1

        if inter_count > 0:
            inter_class_separation /= inter_count

        # 综合损失：鼓励类内紧凑，类间分离
        # 我们希望类内距离小，类间距离大
        # loss = intra_class_compactness - inter_class_separation
        loss = intra_class_compactness + (1/ inter_class_separation)

        return loss
