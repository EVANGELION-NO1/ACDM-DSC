"""Minimal import and shape check; does not read data or train a model."""

from pathlib import Path
import sys

import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ddpm_model import ContextUnet1D  # noqa: E402
from dg_model import BaseModel  # noqa: E402


def main():
    x = torch.randn(2, 1, 2048)
    labels = torch.tensor([0, 1], dtype=torch.long)
    mask = torch.zeros(2, dtype=torch.float32)
    t = torch.ones(2, 1, 1)

    diffusion_model = ContextUnet1D(in_channels=1, n_feat=32, n_classes=3)
    with torch.no_grad():
        diffusion_out = diffusion_model(x, labels, t, mask)
    assert diffusion_out.shape == x.shape, diffusion_out.shape

    diagnosis_model = BaseModel(distance_metric="cosine")
    with torch.no_grad():
        diagnosis_out = diagnosis_model(x.squeeze(1))
    assert diagnosis_out.shape == (2, 2), diagnosis_out.shape

    print("smoke_test: OK")


if __name__ == "__main__":
    main()
