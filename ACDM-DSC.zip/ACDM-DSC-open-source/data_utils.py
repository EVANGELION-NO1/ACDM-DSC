import logging
import os
import torch
import numpy as np
import hashlib
from data_generate.data_set import DatasetBuilder, DatasetConfig

# ==================== 日志设置 ====================
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_LENGTH = int(2048)
# 缓存目录配置
CACHE_DIR = "./data_cache"
os.makedirs(CACHE_DIR, exist_ok=True)
CACHE_VERSION = "v2"  # Mask/order metadata removed from the cache schema.


class AngularFreqDataset(torch.utils.data.Dataset):
    """Dataset adapter for angular-frequency samples."""

    def __init__(self, angular_freq_data, labels=None):
        """
        初始化数据集
        :param angular_freq_data: 角频率数据，形状应为(n_samples, signal_length)
        :param labels: 标签数据，可选
        """
        # 添加通道维度: (n_samples, signal_length) -> (n_samples, 1, signal_length)
        self.data = torch.tensor(angular_freq_data, dtype=torch.float32).unsqueeze(1)

        if labels is not None:
            self.labels = torch.tensor(labels, dtype=torch.long)
        else:
            self.labels = None

        logger.info(f"Dataset created, number of samples: {len(self.data)}")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        if self.labels is not None:
            return self.data[idx], self.labels[idx]
        return self.data[idx]


def get_cache_filename(case_path):
    """生成唯一的缓存文件名"""
    hash_obj = hashlib.md5(case_path.encode())
    return f"cached_{CACHE_VERSION}_{hash_obj.hexdigest()}.npz"


def load_case_data(case_path):
    """Load angular-frequency data and cache the four training arrays."""
    cache_file = os.path.join(CACHE_DIR, get_cache_filename(case_path))

    # 如果缓存存在则直接加载
    if os.path.exists(cache_file):
        print(f"Loading cached data from {cache_file}")
        data = np.load(cache_file, allow_pickle=True)

        train_x = data['train_x']
        train_y = data['train_y']
        test_x = data['test_x']
        test_y = data['test_y']
        return train_x, train_y, test_x, test_y

    # 加载原始数据
    real_data = DatasetBuilder(DatasetConfig(case_path)).build()

    # 归一化原始训练测试集
    train_x = real_data['train']['angular_freq'][:, :DATA_LENGTH]
    test_x = real_data['test']['angular_freq'][:, :DATA_LENGTH]
    train_y = real_data['train']['labels']
    test_y = real_data['test']['labels']

    np.savez_compressed(
        cache_file,
        train_x=train_x, train_y=train_y,
        test_x=test_x, test_y=test_y,
    )
    print(f"Saved processed data to {cache_file}")

    return train_x, train_y, test_x, test_y


def normalize_samples(data):
    """对每个样本单独进行归一化（保持每个样本的时间结构）"""
    normalized_data = data.copy()
    for i in range(normalized_data.shape[0]):
        # 获取当前样本的最小值和最大值
        min_val = np.min(normalized_data[i])
        max_val = np.max(normalized_data[i])

        # 避免除以零的情况
        if max_val != min_val:
            normalized_data[i] = (normalized_data[i] - min_val) / (max_val - min_val)
        else:
            # 如果所有值相同，则设为0或保持原值
            normalized_data[i] = np.zeros_like(normalized_data[i])
    return normalized_data
