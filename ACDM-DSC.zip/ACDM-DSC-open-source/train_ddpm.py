import logging
import os
import torch
import numpy as np
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from tqdm import tqdm
import torch.nn as nn
import argparse
from data_utils import load_case_data, AngularFreqDataset
from ddpm_model import ContextUnet1D


# ==================== 参数配置工厂 ====================
class ConfigFactory:
    """参数配置工厂类，集中管理所有可配置参数"""

    @staticmethod
    def get_default_config():
        """获取默认配置"""
        return {
            # 数据集配置 - 将在这里动态设置
            'DATA_ROOT': "",
            'RESULTS_DIR': "",
            'TEST_RESULTS_DIR': "",

            # # 工况列表
            # 'WORKING_CONDITIONS': ["6204_000w", "6204_200w", "6204_400w"],
            # 'BASE_DATA_ROOT': r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hnust_6204",
            # 'WORKING_CONDITIONS': ["6205_000w", "6205_200w", "6205_400w"],
            # 'BASE_DATA_ROOT': r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hnust_6205",
            # 'WORKING_CONDITIONS': ["6206_000w", "6206_200w", "6206_400w"],
            # 'BASE_DATA_ROOT': r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hnust_6206",

            # 工况列表
            # 'WORKING_CONDITIONS': ["real_pitting_L2_1500rpm_01M_10F", "real_pitting_L2_1500rpm_07M_04F", "real_pitting_L2_1500rpm_07M_10F"],
            # 'BASE_DATA_ROOT': r"E:\Dengzihao\DATASET\Compound_dataset\bearing_pdbu",

            # # 工况列表
            # 'WORKING_CONDITIONS': ["1000rpm_f200", "1000rpm_f400", "1000rpm_f600"],
            # 'BASE_DATA_ROOT': r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hdu",

            # # 工况列表
            # 'WORKING_CONDITIONS': ["Medium_1200rpm", "Medium_1500rpm", "Medium_1800rpm"],
            # 'BASE_DATA_ROOT': r"E:\Dengzihao\DATASET\Compound_dataset\bearing_hust",

            # 'WORKING_CONDITIONS': [ "900rpm", "1200rpm", "1500rpm", "1800rpm"],
            # 'BASE_DATA_ROOT': r"E:\Dengzihao\DATASET\Compound_dataset\bearing_313lg",

            'WORKING_CONDITIONS': ["950rpm", "1000rpm", "1050rpm", "1100rpm"],
            'BASE_DATA_ROOT': r"E:\Dengzihao\DATASET\Compound_dataset\bearing_313lb",


            # 类别配置
            'CLASS_NAMES': {
                0: "Normal",
                1: "BPFI",
                2: "BPFO",
                3: "Compound_Fault",  # 添加复合故障类别
            },
            'NUM_CLASSES': 3,  # 只使用前3个类别进行训练
            'TOTAL_CLASSES': 4,  # 添加总类别数

            # 训练配置
            'BATCH_SIZE': 64,
            'NUM_EPOCHS': 500,
            'LEARNING_RATE': 1e-4,
            'DROP_PROB': 0.1,
            'DATA_LENGTH': 2048,

            # 模型配置
            'NUM_FEATURES': 192,
            'NUM_T': 1000,  # 扩散步骤
            'BETAS': (1e-4, 0.02),

            # 生成样本配置
            'SAMPLES_PER_CLASS': 100,  # 每类生成5个样本
            'COMPOUND_SAMPLES': 100,  # 复合故障每条件生成50个样本
            'GUIDE_WEIGHT': 2.0,

            # 设备配置
            'DEVICE': "cuda" if torch.cuda.is_available() else "cpu",
        }

    @staticmethod
    def create_config_for_condition(condition_name, base_results_dir="./results_diffusion_hnust", data_root=None):
        """为特定工况创建配置"""
        config = ConfigFactory.get_default_config()

        # 动态设置路径
        if data_root is not None:
            config['BASE_DATA_ROOT'] = data_root
        config['DATA_ROOT'] = os.path.join(config['BASE_DATA_ROOT'], condition_name)
        config['RESULTS_DIR'] = os.path.join(base_results_dir, condition_name)
        config['TEST_RESULTS_DIR'] = os.path.join(base_results_dir, condition_name, "test_results_500_GW2.0")

        return type('Config', (), config)()


# ==================== 日志设置 ====================
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# ==================== DDPM相关函数和类 ====================
def ddpm_schedules(beta1, beta2, T):
    """返回DDPM采样和训练过程的预计算调度"""
    assert beta1 < beta2 < 1.0, "beta1和beta2必须在(0, 1)范围内"

    beta_t = (beta2 - beta1) * torch.arange(0, T + 1, dtype=torch.float32) / T + beta1
    sqrt_beta_t = torch.sqrt(beta_t)
    alpha_t = 1 - beta_t
    log_alpha_t = torch.log(alpha_t)
    alphabar_t = torch.cumsum(log_alpha_t, dim=0).exp()

    sqrtab = torch.sqrt(alphabar_t)
    oneover_sqrta = 1 / torch.sqrt(alpha_t)

    sqrtmab = torch.sqrt(1 - alphabar_t)
    mab_over_sqrtmab_inv = (1 - alpha_t) / sqrtmab

    return {
        "alpha_t": alpha_t,
        "oneover_sqrta": oneover_sqrta,
        "sqrt_beta_t": sqrt_beta_t,
        "alphabar_t": alphabar_t,
        "sqrtab": sqrtab,
        "sqrtmab": sqrtmab,
        "mab_over_sqrtmab": mab_over_sqrtmab_inv,
    }


class DDPM1D(nn.Module):
    def __init__(self, nn_model, betas, n_T, device, drop_prob, num_classes):
        super(DDPM1D, self).__init__()
        self.nn_model = nn_model.to(device)
        self.num_classes = num_classes  # 保存num_classes

        # 注册ddpm_schedules产生的缓冲区
        for k, v in ddpm_schedules(betas[0], betas[1], n_T).items():
            self.register_buffer(k, v)

        self.n_T = n_T
        self.device = device
        self.drop_prob = drop_prob
        self.loss_mse = nn.MSELoss()

    def forward(self, x, c):
        """此方法用于训练，因此随机采样t和噪声"""
        _ts = torch.randint(1, self.n_T + 1, (x.shape[0],)).to(self.device)  # t ~ Uniform(0, n_T)
        noise = torch.randn_like(x)  # eps ~ N(0, 1)

        x_t = (
                self.sqrtab[_ts, None, None] * x
                + self.sqrtmab[_ts, None, None] * noise
        )

        # 以一定概率丢弃上下文
        context_mask = torch.bernoulli(torch.zeros_like(c) + self.drop_prob).to(self.device)

        # 返回添加的噪声和预测噪声之间的MSE
        return self.loss_mse(noise, self.nn_model(x_t, c, _ts / self.n_T, context_mask))

    def sample(self, n_sample, size, device, guide_w=10, specific_class=None):
        # 如果指定了特定类别，则生成该类别的样本
        if specific_class is not None:
            c_i = torch.full((n_sample,), specific_class, dtype=torch.long).to(device)
        else:
            # 确保n_sample是NUM_CLASSES的倍数，以便平均分配所有类别
            if n_sample % self.num_classes != 0:
                n_sample = (n_sample // self.num_classes + 1) * self.num_classes

            # 创建条件标签，确保每个类别都有样本
            c_i = torch.arange(0, self.num_classes).to(device)  # 上下文，0-2的标签
            c_i = c_i.repeat(n_sample // self.num_classes)

            # 确保条件标签的批次大小与输入一致
            if len(c_i) != n_sample:
                # 如果仍然不匹配，调整条件标签
                c_i = c_i[:n_sample]

        x_i = torch.randn(n_sample, *size).to(device)  # x_T ~ N(0, 1)，采样初始噪声

        # 测试时不丢弃上下文
        context_mask = torch.zeros_like(c_i).to(device)

        # 加倍批次用于无分类器引导
        c_i_double = c_i.repeat(2)
        context_mask_double = context_mask.repeat(2)
        context_mask_double[n_sample:] = 1.  # 使批次的第二部分无上下文

        print()
        for i in range(self.n_T, 0, -1):
            print(f'sampling timestep {i}', end='\r')
            t_is = torch.tensor([i / self.n_T]).to(device)
            t_is = t_is.repeat(n_sample, 1, 1)

            # 加倍批次
            x_i_double = x_i.repeat(2, 1, 1)
            t_is_double = t_is.repeat(2, 1, 1)

            z = torch.randn(n_sample, *size).to(device) if i > 1 else 0

            # 分割预测并计算权重
            eps = self.nn_model(x_i_double, c_i_double, t_is_double, context_mask_double)
            eps1 = eps[:n_sample]
            eps2 = eps[n_sample:]
            eps = (1 + guide_w) * eps1 - guide_w * eps2
            x_i = x_i
            x_i = (
                    self.oneover_sqrta[i] * (x_i - eps * self.mab_over_sqrtmab[i])
                    + self.sqrt_beta_t[i] * z
            )

        return x_i, c_i


# ==================== 混合条件采样器 ====================
class MixedConditionSampler:
    """处理混合条件采样的工具类"""

    @staticmethod
    def sample_with_mixed_condition(ddpm, mixed_weights, n_sample, size, device, guide_w=3.0):
        """使用混合条件生成样本"""
        # 确保权重和为1
        mixed_weights = torch.tensor(mixed_weights, dtype=torch.float32, device=device)
        mixed_weights = mixed_weights / mixed_weights.sum()

        # 创建混合条件标签 (multi-hot编码)
        mixed_condition = mixed_weights.repeat(n_sample, 1)

        # 初始化噪声
        x_i = torch.randn(n_sample, *size).to(device)

        # 创建上下文掩码（全部不屏蔽）
        context_mask = torch.zeros(n_sample, dtype=torch.long).to(device)

        # 加倍批次用于无分类器引导
        mixed_condition_double = mixed_condition.repeat(2, 1)
        context_mask_double = context_mask.repeat(2)
        context_mask_double[n_sample:] = 1.0  # 使批次的第二部分无上下文

        # 采样循环
        for i in range(ddpm.n_T, 0, -1):
            print(f'sampling timestep {i}', end='\r')
            t_is = torch.tensor([i / ddpm.n_T]).to(device)
            t_is = t_is.repeat(n_sample, 1, 1)

            # 加倍批次
            x_i_double = x_i.repeat(2, 1, 1)
            t_is_double = t_is.repeat(2, 1, 1)

            z = torch.randn(n_sample, *size).to(device) if i > 1 else 0

            # 分割预测并计算权重
            eps = ddpm.nn_model(x_i_double, mixed_condition_double, t_is_double, context_mask_double)
            eps1 = eps[:n_sample]
            eps2 = eps[n_sample:]
            eps = (1 + guide_w) * eps1 - guide_w * eps2

            x_i = (
                    ddpm.oneover_sqrta[i] * (x_i - eps * ddpm.mab_over_sqrtmab[i])
                    + ddpm.sqrt_beta_t[i] * z
            )

        return x_i


# ==================== 训练函数 ====================
def train_diffusion(config):
    # 设置随机种子
    torch.manual_seed(42)
    np.random.seed(42)

    # 加载数据
    train_x, train_y, test_x, test_y = load_case_data(config.DATA_ROOT)

    # 归一化数据
    # train_x = normalize_samples(train_x)

    # 过滤数据，只保留前3个类别的样本
    train_mask = train_y < 3
    train_x = train_x[train_mask]
    train_y = train_y[train_mask]

    logger.info(f"Angular frequency data shape: {train_x.shape}")
    logger.info(f"Label data shape: {train_y.shape}")
    logger.info(f"Training only on classes 0, 1, 2. Class 3 (Compound Fault) will be used for comparison only.")

    # 创建PyTorch数据集
    train_dataset = AngularFreqDataset(train_x, train_y)
    logger.info(f"Training set size: {len(train_dataset)}")

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.BATCH_SIZE,
        pin_memory=True,
        shuffle=True,
        drop_last=True,
    )

    # 创建模型
    nn_model = ContextUnet1D(in_channels=1, n_feat=config.NUM_FEATURES, n_classes=config.NUM_CLASSES)
    ddpm = DDPM1D(
        nn_model=nn_model,
        betas=config.BETAS,
        n_T=config.NUM_T,
        device=config.DEVICE,
        drop_prob=config.DROP_PROB,
        num_classes=config.NUM_CLASSES  # 传递num_classes
    )
    ddpm = ddpm.to(config.DEVICE)

    # 创建优化器
    optim = torch.optim.Adam(ddpm.parameters(), lr=config.LEARNING_RATE)

    # 训练循环
    os.makedirs(config.RESULTS_DIR, exist_ok=True)

    for ep in range(config.NUM_EPOCHS):
        print(f'epoch {ep}')
        ddpm.train()

        # 线性学习率衰减
        optim.param_groups[0]['lr'] = config.LEARNING_RATE * (1 - ep / config.NUM_EPOCHS)

        loss_ema = None
        pbar = tqdm(train_loader)
        for x, c in pbar:
            optim.zero_grad()
            x = x.to(config.DEVICE)
            c = c.to(config.DEVICE)
            loss = ddpm(x, c)
            loss.backward()
            if loss_ema is None:
                loss_ema = loss.item()
            else:
                loss_ema = 0.95 * loss_ema + 0.05 * loss.item()
            pbar.set_description(f"loss: {loss_ema:.4f}")
            optim.step()

    # 保存最终模型
    final_model_path = os.path.join(config.RESULTS_DIR, f"model_final.pth")
    torch.save(ddpm.state_dict(), final_model_path)
    print(f'saved final model at {final_model_path}')

    return ddpm, final_model_path


# ==================== 评估函数 ====================
def eval_diffusion(config, model_path):
    # 设置随机种子
    torch.manual_seed(42)
    np.random.seed(42)

    # 加载数据用于对比
    train_x, train_y, test_x, test_y = load_case_data(config.DATA_ROOT)

    # 创建模型
    nn_model = ContextUnet1D(in_channels=1, n_feat=config.NUM_FEATURES, n_classes=config.NUM_CLASSES)
    ddpm = DDPM1D(
        nn_model=nn_model,
        betas=config.BETAS,
        n_T=config.NUM_T,
        device=config.DEVICE,
        drop_prob=config.DROP_PROB,
        num_classes=config.NUM_CLASSES  # 传递num_classes
    )

    # 加载训练好的模型
    ddpm.load_state_dict(torch.load(model_path, map_location=config.DEVICE))
    ddpm = ddpm.to(config.DEVICE)
    ddpm.eval()

    # 创建结果目录
    os.makedirs(config.TEST_RESULTS_DIR, exist_ok=True)

    # 生成样本并与原始样本对比
    with torch.no_grad():
        # 创建各种目录
        comparison_dir = os.path.join(config.TEST_RESULTS_DIR, "comparison")
        mixed_dir = os.path.join(config.TEST_RESULTS_DIR, "mixed_conditions")
        tsne_dir = os.path.join(config.TEST_RESULTS_DIR, "tsne_visualization")
        compound_dir = os.path.join(config.TEST_RESULTS_DIR, "compound_comparison")
        compound_samples_dir = os.path.join(config.TEST_RESULTS_DIR, "compound_samples")
        single_samples_dir = os.path.join(config.TEST_RESULTS_DIR, "single_samples")  # 新增单类样本目录

        for dir_path in [comparison_dir, mixed_dir, tsne_dir, compound_dir, compound_samples_dir, single_samples_dir]:
            os.makedirs(dir_path, exist_ok=True)

        # 获取每个类别的真实样本
        real_samples = {}
        real_compound_samples = []  # 存储真实复合故障样本
        for i in range(config.TOTAL_CLASSES):
            if i < 3:
                class_indices = np.where(train_y == i)[0]
            else:
                class_indices = np.where(test_y == i)[0]

            if len(class_indices) > 0:
                sample_idx = class_indices[0]
                if i < 3:
                    real_samples[i] = train_x[sample_idx]
                else:
                    real_samples[i] = test_x[sample_idx]

                # 收集真实复合故障样本用于对比
                if i == 3:  # 复合故障
                    real_compound_samples.extend(test_x[class_indices])

        # 新增：为每个单类故障（包括健康状态）生成100个样本
        all_single_samples = []
        all_single_labels = []

        for class_id in range(config.NUM_CLASSES):  # 0, 1, 2
            print(f"Generating {config.SAMPLES_PER_CLASS} samples for class {class_id}")

            x_gen, labels = ddpm.sample(
                n_sample=config.SAMPLES_PER_CLASS,
                size=(1, config.DATA_LENGTH),
                device=config.DEVICE,
                guide_w=config.GUIDE_WEIGHT,
                specific_class=class_id
            )

            # 保存生成的单类样本
            all_single_samples.append(x_gen.cpu().numpy())
            all_single_labels.extend([class_id] * config.SAMPLES_PER_CLASS)

            # 保存单类样本到文件
            np.save(os.path.join(single_samples_dir, f"class_{class_id}_samples.npy"), x_gen.cpu().numpy())

            # 创建对比图（只绘制前5个）
            if class_id in real_samples:
                fig, axes = plt.subplots(min(5, config.SAMPLES_PER_CLASS) + 1, 1,
                                         figsize=(12, 3 * (min(5, config.SAMPLES_PER_CLASS) + 1)))

                axes[0].plot(real_samples[class_id])
                axes[0].set_title(f'Real {config.CLASS_NAMES[class_id]} Sample')
                axes[0].grid(True)

                for i in range(min(5, config.SAMPLES_PER_CLASS)):
                    axes[i + 1].plot(x_gen[i][0].cpu().numpy())
                    axes[i + 1].set_title(f'Generated {config.CLASS_NAMES[class_id]} Sample {i + 1}')
                    axes[i + 1].grid(True)

                plt.tight_layout()
                plt.savefig(os.path.join(comparison_dir, f"comparison_{config.CLASS_NAMES[class_id]}.png"))
                plt.close()

        # 合并所有单类样本
        if all_single_samples:
            single_samples_np = np.concatenate(all_single_samples, axis=0)
            single_labels_np = np.array(all_single_labels)

            # 保存所有单类样本
            np.save(os.path.join(single_samples_dir, "all_single_samples.npy"), single_samples_np)
            np.save(os.path.join(single_samples_dir, "all_single_labels.npy"), single_labels_np)
            print(f"Generated total {single_samples_np.shape[0]} single-class samples.")

        # 定义混合条件权重
        mixed_conditions = [
            {"name": "Mixed_BPFI_40_BPFO_60", "weights": [0, 0.4, 0.6]},
            {"name": "Mixed_BPFI_50_BPFO_50", "weights": [0, 0.5, 0.5]},
            {"name": "Mixed_BPFI_60_BPFO_40", "weights": [0, 0.6, 0.4]},
        ]

        # 存储所有生成的混合样本
        all_generated_samples = {}
        all_compound_samples = []

        # 生成复合故障样本
        for mixed_cond in mixed_conditions:
            mixed_name = mixed_cond["name"]
            mixed_weights = mixed_cond["weights"]

            print(f"Generating samples for mixed condition: {mixed_name}")

            x_gen = MixedConditionSampler.sample_with_mixed_condition(
                ddpm=ddpm,
                mixed_weights=mixed_weights,
                n_sample=config.COMPOUND_SAMPLES,
                size=(1, config.DATA_LENGTH),
                device=config.DEVICE,
                guide_w=config.GUIDE_WEIGHT
            )

            all_generated_samples[mixed_name] = x_gen.cpu().numpy()
            all_compound_samples.append(x_gen.cpu().numpy())

            # 保存样本到文件
            np.save(os.path.join(mixed_dir, f"{mixed_name}_samples_{config.COMPOUND_SAMPLES}.npy"), x_gen.cpu().numpy())

            # 保存样本图像
            for i in range(min(3, config.COMPOUND_SAMPLES)):
                plt.figure(figsize=(10, 4))
                plt.plot(x_gen[i][0].cpu().numpy())
                plt.title(f'Generated {mixed_name} Sample {i + 1}')
                plt.savefig(os.path.join(mixed_dir, f"generated_{mixed_name}_{i + 1}.png"))
                plt.close()

            # 保存权重信息
            with open(os.path.join(mixed_dir, f"weights_{mixed_name}.txt"), "w") as f:
                for i, weight in enumerate(mixed_weights):
                    if weight > 0:
                        f.write(f"{config.CLASS_NAMES[i]}: {weight:.2f}\n")

        # 将所有复合故障样本合并为一个数组
        compound_samples_np = np.concatenate(all_compound_samples, axis=0)
        print(f"Generated total {compound_samples_np.shape[0]} compound fault samples.")

        # 保存复合故障样本到文件
        np.save(os.path.join(compound_samples_dir, "compound_fault_samples.npy"), compound_samples_np)

        # ==================== 按混合比例分别对比 ====================
        if len(real_compound_samples) > 0:
            print("Creating detailed compound fault comparisons by mixed condition...")

            # 为每种混合条件创建单独的对比
            for mixed_cond in mixed_conditions:
                mixed_name = mixed_cond["name"]
                mixed_weights = mixed_cond["weights"]

                # 获取该混合条件生成的所有样本
                if mixed_name in all_generated_samples:
                    gen_samples = all_generated_samples[mixed_name]

                    # 创建该混合条件的专用目录
                    condition_dir = os.path.join(compound_dir, mixed_name)
                    os.makedirs(condition_dir, exist_ok=True)

                    # 随机选择几个真实复合样本和生成样本
                    num_comparison_samples = min(5, len(real_compound_samples), gen_samples.shape[0])
                    real_indices = np.random.choice(len(real_compound_samples), num_comparison_samples, replace=False)
                    gen_indices = np.random.choice(gen_samples.shape[0], num_comparison_samples, replace=False)

                    real_selected = [real_compound_samples[i] for i in real_indices]
                    gen_selected = gen_samples[gen_indices]

                    # 创建分开展示的对比图
                    fig, axes = plt.subplots(num_comparison_samples, 2,
                                             figsize=(15, 3 * num_comparison_samples))
                    fig.suptitle(f'Real vs Generated Compound Fault Samples - {mixed_name}', fontsize=16)

                    # 如果只有一行，调整axes形状
                    if num_comparison_samples == 1:
                        axes = axes.reshape(1, 2)

                    for i in range(num_comparison_samples):
                        # 真实样本
                        axes[i, 0].plot(real_selected[i], 'b-', alpha=0.8, linewidth=1.5)
                        axes[i, 0].set_title(f'Real Compound Sample {i + 1}', fontsize=12)
                        axes[i, 0].grid(True, alpha=0.3)
                        axes[i, 0].set_ylabel('Amplitude')

                        # 生成样本
                        axes[i, 1].plot(gen_selected[i, 0], 'r-', alpha=0.8, linewidth=1.5)
                        axes[i, 1].set_title(f'Generated {mixed_name} Sample {i + 1}', fontsize=12)
                        axes[i, 1].grid(True, alpha=0.3)
                        axes[i, 1].set_ylabel('Amplitude')

                    plt.tight_layout()
                    plt.savefig(os.path.join(condition_dir, f"side_by_side_comparison.png"),
                                dpi=300, bbox_inches='tight')
                    plt.close()

                    # 创建叠加对比图
                    plt.figure(figsize=(12, 8))
                    for i in range(num_comparison_samples):
                        plt.subplot(num_comparison_samples, 1, i + 1)

                        # 叠加绘制真实和生成样本
                        plt.plot(real_selected[i], 'b-', alpha=0.7, linewidth=1.5,
                                 label='Real Compound')
                        plt.plot(gen_selected[i, 0], 'r-', alpha=0.7, linewidth=1.5,
                                 label=f'Generated {mixed_name}')

                        plt.title(f'Sample {i + 1} - Real vs Generated Overlay', fontsize=12)
                        plt.ylabel('Amplitude')
                        plt.grid(True, alpha=0.3)
                        plt.legend()

                    plt.tight_layout()
                    plt.savefig(os.path.join(condition_dir, f"overlay_comparison.png"),
                                dpi=300, bbox_inches='tight')
                    plt.close()

                    print(f"Detailed comparison for {mixed_name} saved to {condition_dir}")

        # ==================== 所有混合条件汇总对比 ====================
        if len(real_compound_samples) > 0 and len(mixed_conditions) > 0:
            print("Creating summary comparison of all mixed conditions...")

            summary_dir = os.path.join(compound_dir, "summary_comparison")
            os.makedirs(summary_dir, exist_ok=True)

            # 选择几个样本进行汇总对比
            num_summary_samples = min(3, len(real_compound_samples))
            real_summary = real_compound_samples[:num_summary_samples]

            # 创建汇总对比图
            # 创建汇总对比图
            for sample_idx in range(num_summary_samples):
                plt.figure(figsize=(15, 10))

                # 绘制真实样本
                plt.subplot(2, 1, 1)
                plt.plot(real_summary[sample_idx], 'k-', linewidth=2, label='Real Compound')
                plt.title(f'Real Compound Fault Sample {sample_idx + 1}', fontsize=14)
                plt.ylabel('Amplitude')
                plt.grid(True, alpha=0.3)
                plt.legend()

                # 绘制所有混合条件的生成样本
                plt.subplot(2, 1, 2)
                colors = plt.cm.Set3(np.linspace(0, 1, len(mixed_conditions)))

                for i, mixed_cond in enumerate(mixed_conditions):
                    mixed_name = mixed_cond["name"]
                    if mixed_name in all_generated_samples:
                        gen_samples = all_generated_samples[mixed_name]
                        if sample_idx < gen_samples.shape[0]:
                            plt.plot(gen_samples[sample_idx, 0],
                                     color=colors[i],
                                     alpha=0.7,
                                     linewidth=1.5,
                                     label=mixed_name)

                plt.title(f'Generated Samples from Different Mixed Conditions (Sample {sample_idx + 1})',
                          fontsize=14)
                plt.ylabel('Amplitude')
                plt.xlabel('Data Points')
                plt.grid(True, alpha=0.3)
                plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')

                plt.tight_layout()
                plt.savefig(os.path.join(summary_dir, f"summary_comparison_sample_{sample_idx + 1}.png"),
                            dpi=300, bbox_inches='tight')
                plt.close()

            print(f"Summary comparisons saved to {summary_dir}")

        # 保存所有生成的样本到文件
    np.savez(os.path.join(mixed_dir, "all_generated_samples.npz"), **all_generated_samples)

    # 新增：保存所有样本（单类和复合）的汇总文件
    print("Saving all generated samples summary...")

    # 创建样本汇总
    all_samples_summary = {
        'single_samples': single_samples_np if 'single_samples_np' in locals() else None,
        'single_labels': single_labels_np if 'single_labels_np' in locals() else None,
        'compound_samples': compound_samples_np,
        'compound_labels': np.full(compound_samples_np.shape[0], 3)  # 复合故障标签为3
    }

    # 保存汇总文件
    np.savez(os.path.join(config.TEST_RESULTS_DIR, "all_generated_samples_summary.npz"), **all_samples_summary)

    print(
        f"All samples summary saved to {os.path.join(config.TEST_RESULTS_DIR, 'all_generated_samples_summary.npz')}")

    # TSNE可视化
    print("Preparing data for TSNE visualization...")

    # 准备原始数据
    original_samples = []
    original_labels = []

    samples_per_original_class = 50
    for class_id in range(config.TOTAL_CLASSES):
        if class_id < 3:
            class_indices = np.where(train_y == class_id)[0]
        else:
            class_indices = np.where(test_y == class_id)[0]

        if len(class_indices) > 0:
            selected_indices = np.random.choice(
                class_indices,
                size=min(samples_per_original_class, len(class_indices)),
                replace=False
            )
            for idx in selected_indices:
                if class_id < 3:
                    original_samples.append(train_x[idx])
                else:
                    original_samples.append(test_x[idx])
                original_labels.append(f"Original_{config.CLASS_NAMES[class_id]}")

    # 准备生成的数据
    generated_samples = []
    generated_labels = []

    # 添加单类故障样本
    if 'single_samples_np' in locals() and single_samples_np is not None:
        for i in range(single_samples_np.shape[0]):
            generated_samples.append(single_samples_np[i, 0])
            generated_labels.append(f"Generated_{config.CLASS_NAMES[all_single_labels[i]]}")

    # 添加复合故障样本
    for mixed_name, samples in all_generated_samples.items():
        for i in range(samples.shape[0]):
            generated_samples.append(samples[i, 0])
            generated_labels.append(f"Generated_{mixed_name}")

    # 合并所有样本
    all_samples = np.array(original_samples + generated_samples)
    all_labels = np.array(original_labels + generated_labels)

    print(f"Total samples for TSNE: {len(all_samples)}")
    print(f"Original samples: {len(original_samples)}")
    print(f"Generated samples: {len(generated_samples)}")

    # 执行TSNE降维
    if len(all_samples) > 0:
        print("Running TSNE...")
        tsne = TSNE(n_components=2, random_state=42, perplexity=min(30, len(all_samples) - 1))
        tsne_results = tsne.fit_transform(all_samples)

        # 创建TSNE可视化
        plt.figure(figsize=(16, 12))

        unique_labels = np.unique(all_labels)
        colors = plt.cm.tab20(np.linspace(0, 1, len(unique_labels)))
        markers = ['o', 's', '^', 'D', 'v', '<', '>', 'p', '*', 'h', 'H', '+', 'x', 'X', 'd', '|', '_']

        for i, label in enumerate(unique_labels):
            indices = np.where(all_labels == label)[0]
            marker_size = 100 if "Original" in label else 50
            alpha_val = 0.7 if "Original" in label else 0.5

            plt.scatter(
                tsne_results[indices, 0],
                tsne_results[indices, 1],
                c=[colors[i]],
                marker=markers[i % len(markers)],
                label=label,
                s=marker_size,
                alpha=alpha_val
            )

        plt.title('TSNE Visualization of Original and Generated Samples')
        plt.xlabel('TSNE Dimension 1')
        plt.ylabel('TSNE Dimension 2')
        plt.legend(bbox_to_anchor=(np.array([1.05, 1])), loc='upper left')
        plt.tight_layout()
        plt.savefig(os.path.join(tsne_dir, 'tsne_visualization.png'), dpi=300, bbox_inches='tight')
        plt.close()

        print(f"TSNE visualization saved to {os.path.join(tsne_dir, 'tsne_visualization.png')}")
    else:
        print("Warning: No samples available for TSNE visualization.")

    print(f"Test completed. Results saved to {config.TEST_RESULTS_DIR}")

# ==================== 主程序入口 ====================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train and evaluate the ACDM diffusion model.")
    parser.add_argument("--data-root", default=None,
                        help="Dataset root containing one subdirectory per working condition.")
    parser.add_argument("--results-root", default="./results_diffusion_313lb",
                        help="Directory used to save diffusion models and generated samples.")
    parser.add_argument("--conditions", nargs="+",
                        default=["950rpm", "1000rpm", "1050rpm", "1100rpm"],
                        help="Working-condition directory names.")
    args = parser.parse_args()

    # 三个工况轮流训练和测试
    # working_conditions = ["6204_000w", "6204_200w", "6204_400w"]
    # working_conditions = ["6205_000w", "6205_200w", "6205_400w"]
    # working_conditions = ["6206_000w", "6206_200w", "6206_400w"]
    # base_results_dir = "./results_diffusion_hnust"

    # working_conditions = ["real_pitting_L2_1500rpm_01M_10F", "real_pitting_L2_1500rpm_07M_04F", "real_pitting_L2_1500rpm_07M_10F"]
    # base_results_dir = "./results_diffusion_pdbu"

    # working_conditions = ["1000rpm_f200", "1000rpm_f400", "1000rpm_f600"]
    # base_results_dir = "./results_diffusion_hdu"

    # working_conditions = ["Medium_1200rpm", "Medium_1500rpm", "Medium_1800rpm"]
    # base_results_dir = "./results_diffusion_hust"

    # working_conditions = [ "900rpm", "1200rpm", "1500rpm", "1800rpm"]
    # base_results_dir = "./results_diffusion_313lg"

    working_conditions = args.conditions
    base_results_dir = args.results_root


    for condition in working_conditions:
        print(f"\n{'=' * 60}")
        print(f"开始处理工况: {condition}")
        print(f"{'=' * 60}")

        # 为当前工况创建配置
        config = ConfigFactory.create_config_for_condition(
            condition, base_results_dir, data_root=args.data_root
        )

        # 训练模型
        print(f"开始训练 {condition}...")
        try:
            model, model_path = train_diffusion(config)
            print(f"✓ 训练完成: {condition}")
        except Exception as e:
            print(f"✗ 训练失败: {condition}, 错误: {e}")
            continue

        # 测试模型
        print(f"开始测试 {condition}...")
        try:
            eval_diffusion(config, model_path)
            print(f"✓ 测试完成: {condition}")
        except Exception as e:
            print(f"✗ 测试失败: {condition}, 错误: {e}")
            continue

        print(f"工况 {condition} 处理完成!")
        print(f"模型保存路径: {model_path}")
        print(f"测试结果保存路径: {config.TEST_RESULTS_DIR}")
        print(f"{'=' * 60}\n")

    print("所有工况处理完成!")
